//
//  EBDAppDeletate.h
//
//
//
//
//

//#import <Foundation/Foundation.h>
#import "UnityAppController.h"

#ifndef EBDAppDeletate_h
#define EBDAppDeletate_h

@interface EBDAppDeletate : UnityAppController

@end

#endif /* EBDAppDeletate_h */
